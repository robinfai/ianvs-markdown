---
title: Ianvs Markdown Playground
author: Ianvs
tags: [Flutter, Markdown, live-preview]
aliases: [Ianvs editor, Markdown playground]
status: editable
enabled: true
archived: false
score: 42
due: 2026-09-03
related: ["[[Project Notes]]", "https://flutter.dev"]
empty:
settings: {owner: Ianvs, autosave: true}
---
# Render and edit together

Click any rendered block to edit its exact **Markdown source** without leaving
Live Preview. Use the toolbar to switch between Live Preview, Source, and Read.

> Markdown remains the only source of truth. The host application decides how
> files, links, images, and persistence are handled.

## Text and inline formatting

A normal paragraph can contain **bold**, *italic*, ***bold italic***,
~~strikethrough~~, ==highlighted text==, and `inline code`.

Escaped characters stay literal: \*asterisks\*, \#hash, and
\[brackets\].
Two spaces at the end of this line create a hard break:  
this sentence starts on the next visual line.

Links support [relative destinations](docs/guide.md),
[titles](https://example.com "Example title"), and bare URLs such as
https://flutter.dev. Email addresses like hello@example.com remain readable.

Wiki links keep their source: [[Project Notes]], [[Project Notes#Roadmap]], and
[[docs/roadmap|a custom label]]. Hierarchical tags render compactly:
#flutter/markdown.

## Lists and tasks

- Unordered item
- A second item with nested content
  - Nested bullet
  - Another nested bullet
    1. Ordered item at a deeper level
    2. Another ordered item
- Final parent item

1. First ordered item
2. Second ordered item
3. Third ordered item

- [x] Completed task
- [ ] Open task
- [ ] Task containing **formatted text** and a [link](https://dart.dev)

## Quotes and callouts

> A blockquote can span multiple lines.
>
> It can contain **formatting**, lists, and a second paragraph.
> - Quoted list item

> An outer quote keeps its first rail.
>
> > A nested quote adds another level.

> [!note] Live Preview
> Callouts keep their title, accent, and Markdown **formatting**.

> [!warning]- Collapsible detail
> This warning starts folded and preserves its exact source.

---

## Headings

### Heading level three

#### Heading level four

##### Heading level five

###### Heading level six

Setext level one
================

Setext level two
----------------

## Tables

| Capability | Example | Supported |
| :--- | :--- | ---: |
| Inline styles | **Bold** and `code` | Yes |
| Alignment | Left and right columns | Yes |
| Empty cell | | Yes |
| Escaped pipe | A \| B | Yes |

## Code

Inline code preserves symbols such as `final value = <String>[];`.

```dart
final controller = IanvsMarkdownController(
  text: '# Hello Markdown',
);

IanvsMarkdownLiveEditor(controller: controller);
```

Indented code is also supported:

    const unfenced = true;
    print(unfenced);

## Mermaid diagram

Without a host-supplied `diagramBuilder`, Mermaid remains a code block.
The optional native adapter has its own example in the repository.

```mermaid
flowchart LR
  Markdown --> Parse
  Parse --> Edit
  Edit --> Render
```

## Math

Inline math uses delimiters such as $E = mc^2$.

$$
\int_0^1 x^2\,dx = \frac{1}{3}
$$

## Images and embeds

Images display a placeholder until the host supplies an `imageBuilder`:

![Frame diff principle advantages](https://robinfai.github.io/ianvs-terminal/assets/images/frame-diff/principle-advantages.png "Frame diff principle advantages")

Obsidian-style embeds retain their exact source:

![[Project Notes#Roadmap]]

## Footnotes, comments, and block IDs

A statement can reference a standard footnote[^source] and an inline footnote
^[Inline notes share the same reading-mode sequence.].

[^source]: Footnote definitions can contain **Markdown formatting** and links.

This text is visible, while %%this editor-only comment is hidden in Read mode%%.

This paragraph has a reusable block identifier. ^example-block

%%
A multi-line Markdown comment remains editable in Live Preview and disappears
from the reading surface.
%%

## Host integration

| API | Responsibility |
| --- | --- |
| `IanvsMarkdownController` | source, selection, history, dirty state |
| `IanvsMarkdownLiveEditor` | editing and rendering surfaces |
| `diagramBuilder` | host-approved Mermaid rendering |
| `onSaveRequested` | host-owned persistence callback |

The reset button restores this entire document, so every supported element can
be edited repeatedly without changing files on disk.
