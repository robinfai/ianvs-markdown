# L08 input

seed 