---
title: 本地恢复 中文😀
---
# Source fidelity

**保真** [link](second.md)  
	indent

| A | B |
| --- | --- |
| a \| b | 😀 |

```dart
final value = "中文";
```
No final newlineUNSAVEDRECOVERY